import {
  Directive,
  ElementRef,
  HostListener,
  HostBinding,
  Renderer2,
  Input,
} from '@angular/core';

@Directive({
  selector: '[appBlueHighlight]',
})
export class BlueHighlightDirective {
  @Input() highlightDefaultColor: string = 'red';
  @HostBinding('style.background') backgroundColor: string = 'transparent';

  constructor() {}

  @HostListener('mouseenter', ['$event']) onMouseOver(eventData: Event) {
    this.backgroundColor = this.highlightDefaultColor;
  }

  @HostListener('mouseleave', ['$event']) onMouseLeave(eventData: Event) {
    this.backgroundColor = 'transparent';
  }
}
