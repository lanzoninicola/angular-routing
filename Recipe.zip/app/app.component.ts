import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  navMenuSelected: string = 'recipes';

  onMenuSelection(item: string) {
    this.navMenuSelected = item;
  }
}
