import {
  Component,
  OnInit,
  Output,
  EventEmitter,
  Input,
  DoCheck,
} from '@angular/core';
import { Ingredient } from 'src/app/shared/ingredient.model';

@Component({
  selector: 'app-shopping-edit',
  templateUrl: './shopping-edit.component.html',
  styleUrls: ['./shopping-edit.component.css'],
})
export class ShoppingEditComponent implements OnInit, DoCheck {
  @Input() ingredientSelected: Ingredient;
  @Output() ingredientAdded = new EventEmitter<object>();
  @Output() ingredientDeleted = new EventEmitter<string>();

  ingredientName: string = '';
  ingredientAmount: string = '';

  constructor() {}

  ngOnInit() {}

  ngDoCheck() {
    if (this.ingredientSelected) {
      this.ingredientName = this.ingredientSelected?.name;
      this.ingredientAmount = this.ingredientSelected?.amount.toString();
    }
  }

  onIngredientNameChanged(nameInput: HTMLInputElement) {
    this.ingredientName = nameInput.value;
  }

  onIngredientAmountChanged(inputAmount: HTMLInputElement) {
    this.ingredientAmount = inputAmount.value;
  }

  onIngredientAdded(data: Ingredient): void {
    this.ingredientAdded.emit(data);
  }

  onIngredientRemoved(name: string) {
    this.ingredientDeleted.emit(name);
  }

  onIngredientsClear() {}
}
